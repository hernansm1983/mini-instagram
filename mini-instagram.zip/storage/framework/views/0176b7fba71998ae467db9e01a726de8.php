<?php if(\Auth::user()->image): ?>
<div class="container-avatar">
    <img src="<?php echo e(url('../storage/app/users', ['filename'=>Auth::user()->image])); ?>" alt="alt" class="avatar" />   
</div>
<?php endif; ?><?php /**PATH /opt/lampp/htdocs/mini-instagram/resources/views/includes/avatar.blade.php ENDPATH**/ ?>