<?php if(session('message')): ?>
<div class="alert alert-success">
    <?php echo e(session('message')); ?>

</div>
<?php endif; ?><?php /**PATH /opt/lampp/htdocs/mini-instagram/resources/views/includes/message.blade.php ENDPATH**/ ?>